//Write a C program to display the size of the difference datatype

#include <stdio.h>

int main()
{
	printf("%lu\n",sizeof(char));
	printf("%lu\n",sizeof(int));
	printf("%lu\n",sizeof(double));
	printf("%lu\n",sizeof(float));
	return 0;
}
